import Image_1 from './Image_1.jpeg';
import Image_2 from './Image_2.jpeg';
import Image_3 from './Image_3.jpeg';
import Image_4 from './Image_4.jpeg';
import Image_5 from './Image_5.jpeg';
import Image_6 from './Image_6.jpeg';
import Image_7 from './Image_7.jpeg';
import Image_8 from './Image_8.jpeg';
import Image_9 from './Image_9.jpeg';
import Image_10 from './Image_10.jpeg';
import Image_11 from './Image_11.jpeg';
import Image_12 from './Image_12.jpeg';
import Image_13 from './Image_13.jpeg';
import Image_14 from './Image_14.jpeg';
import Image_15 from './Image_15.jpeg';
import Image_16 from './Image_16.jpeg';
import Image_17 from './Image_17.jpeg';
import Hotel1 from './Hotel1.jpeg';
import Hotel2 from "./oester_peral_Saavi_hotel.jpg";
import Hotel3 from "./saavi_hotel_golf_club.jpg";
import Hotel4 from "./saavi_hotel_huda_citycenter.jpeg";
import Hotel5 from "./saavi_hotel_jibhi.jpeg";
import Hotel6 from "./saavi_hotel_medicity.jpg";
import Hotel7 from "./saavi_hotel_sector_10.jpeg";
import Hotel8 from "./saavi_hotel_sector_46.jpg";
import Hotel9 from "./sandlewood_saavi_hotel.jpg";
import F46 from  "./f46.jpeg";
import F45 from  "./f45.jpeg";
import F10 from  "./f10.jpeg";
import Fjb from  "./fjb.jpeg";
import F43 from  "./f43.jpeg";


// Add more imports as needed

const images = {
    Image_1,
    Image_2,
    Image_3,
    Image_4,
    Image_5,
    Image_6,
    Image_7,
    Image_8,
    Image_9,
    Image_10,
    Image_11,
    Image_12,
    Image_13,
    Image_14,
    Image_15,
    Image_16,
    Image_17,
    F46,
    F45,
    F10,
    F43,
    Fjb,
};

const hotels = {
    Hotel1,
    Hotel2,
    Hotel3,
    Hotel4,
    Hotel5,
    Hotel6,
    Hotel7,
    Hotel8,
    Hotel9,
    
};

export { images, hotels };